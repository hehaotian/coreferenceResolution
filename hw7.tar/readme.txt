HW 7 LING 571
HAOTIAN HE
====================

For this homework, I actually finished in a semi-manual process.

Firstly, I write some codes to get the best (top one) parse for each pair in part A, and then I extract both the proposed antecedents and the pronouns from those parse automatically in part B.

After that, I manually went through each pair with its proposed nodes, rejecting all the proposed ones ruled out by agreement in part C, and then identify the accepted antecedent by agreement in part D.

Finally, I indicated whether those accepted antecedents are correct or wrong in E with the same order, and for those wrong, I give an explanation in F2.

The results format for this work is as below:

i) PRP parse_1_sentence_1 parse_2_sentence_2
A) parse_1_sentence_1 parse_2_sentence_2
B) proposed_node_1 proposed_node_2 …
C) reject or accept for each proposed node corresponding to their order in part B
D) list all the accepted antecedent node corresponding to their order in part C
E) correct or wrong for each accepted node corresponding to their order in part D
F2) explanation for those wrong accepted node corresponding to their order in part E